#include <iostream>

using namespace std;

int main()
{
    a[] = new HashTable
    int x = 0;
    while(x != 5){
        cout<<"1.Insert Movie"<<endl;
        cout<<"2.Delete Movie"<<endl;
        cout<<"3.Find Movie"<<endl;
        cout<<"4.Print Table Contents"<<endl;
        cout<<"5.Quit"<<endl;
        if(x = 1){
            string title;
            string year;
            cout<<"Title"<<endl;
            cin>>title;
            cout>>"Year"<<endl;
            cin>>year;
            a.insertMovie(title, year);

        }

        else if(x = 2){
            string title;
            cout<<"Title"<<endl;
            cin>>title;
            a.deleteMovie(title);
        }
        else if(x = 3){
            string title;
            cout<<"Title"<<endl;
            cin>>title;
            a.findMovie(title);

        }
        else if(x = 4){
            a.printTableContents();

        }
    }
    if(x = 5){
        cout<<"GoodBye"<<endl;
    }
}
