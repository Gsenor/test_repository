#include "HashTable.h"

HashTable::HashTable()
{
    //ctor
}

HashTable::~HashTable()
{
    //dtor
}
void printTableContents(){
       list<string>::iterator itr;
    for(int i = 0; i < 10; i++)
{
    if(HashTable[i] != OCCUPIED)
        cout <<(i)<< endl;
}
void insertMovie(name, year){
    int index = hashSum(name, 10);
    HashElem *tmp = new HashElem;
    HashElem *newHash = new HashElem;
    newHash->title = name;
    newHash->next = NULL;
     if(HashElem[index]->next !=NULL){
        newHash->previous = HashTable[index];
        HashTable[index]->next = newHash;
     }else{
         tmp = HashTable[index]->next;
         while(tmp != NULL){
            if(tmp->title == name){
                cout<<"Duplicate"<<endl;
            }else{
            tmp = tmp->next
            }
         }
         tmp = HashTable[index]->next;
         while(tmp->next != NULL && tmp->title > tmp->next->title){
            tmp = tmp->next;
         }
         newHash->next = tmp;
         newHash->previous = tmp->previous;
         tmp->previous->next = newHash
     }


}
void deleteMovie(name){
    int index = hashSum(name, 10);
    if(HashElem[index]->next !=NULL){
        HashElem *tmp = HashElem[index]->next;
        while(tmp!=NULL){
            if(tmp->key == name){
                    if(tmp->next != NULL){
                        tmp->next->previous = tmp->previous;
                        tmp->previous->next = tmp->next;
                    }else{
                        tmp->previous->next = NULL;
                    }
                delete tmp;
                break;
            }else{
            tmp = tmp->next;
            }
}
void findMovie(name){
    int index = hashSum(name, 10);
    if(HashElem[index]->next !=NULL){
        HashElem *tmp = HashElem[index]->next;
        while(tmp!=NULL){
            if(tmp->key == name){
                cout<<index<<endl;
                break;
            }else{
            tmp = tmp->next;
            }
        }
        cout<<"Not Found"<<endl;

    }
}
int hashSum(x,s){
    sum = 0;
    for(int i = 1; i <= x.end; i++){
        sum = sum+key[i];
    }
    sum = sum%s;
    return sum;
 }
